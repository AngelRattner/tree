﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace tree
{
    class Program
    {
        static void Main(string[] args)
        {
            Tree<int> a = new Tree<int>();
            a.Add(5);
            a.Add(4);
            a.Add(3);
            a.Add(7);
            a.Add(8);
            a.Add(1);
            a.Add(6);
            a.ScanInorder(Console.WriteLine);
            Console.ReadLine();
            a.Remove(3);
            a.Remove(7);
            a.ScanInorder(Console.WriteLine);
            Console.ReadLine();
        }
        
    }
    public class Tree<T> where T:IComparable<T>
    {
        Node _root;
        
        class Node
        {
            public Node Right { get; set; }
            public Node Left { get; set; }
            public T Data { get; set; }
            public Node(T value)
            {
                this.Data = value;
            }
        }
        public void Add(T data)
        {
            Node a = new Node(data);
            if (_root == null)
            {
                _root = a;//empty tree
                return;
            }
            else
            {
                Node tmp = this._root, parent = null;
                while (tmp != null)
                {
                    parent = tmp;
                    if (data.CompareTo(tmp.Data) < 0) tmp = tmp.Left;
                    else tmp = tmp.Right;
                }
                if (data.CompareTo(parent.Data) < 0) parent.Left = a;
                else parent.Right = a;
            }
        }
        public void Remove(T data)
        {
            if (_root == null) return; //empty tree
            Node tmp = _root,perent=null;
            while (tmp.Data.CompareTo(data) != 0)//find the number
            {
                perent = tmp;
                if (data.CompareTo(tmp.Data) < 0) tmp = tmp.Left;
                else tmp = tmp.Right;
            }
            if (tmp.Left == null && tmp.Right == null) RemoveEnd(perent, tmp);
            if (tmp.Left != null && tmp.Right != null) RemoveMid(perent, tmp);
            else RemoveOneChild(perent, tmp);
        }

        public void ScanInorder(Action<T> action) => ScanInorder(_root, action);
        private void ScanInorder(Node root,Action<T> action )
        {
            if (root == null) return;
            ScanInorder(root.Left, action);
            action(root.Data);
            ScanInorder(root.Right, action);
        }
        private void RemoveEnd(Node perent,Node tmp)
        {
            if (tmp.Data.CompareTo(perent.Data) < 0) perent.Left = null;
            else perent.Right = null;
        }
        private void RemoveOneChild(Node perent, Node tmp)
        {
            if (tmp.Left != null)
            {
                if (tmp.Data.CompareTo(perent.Data) < 0) perent.Left = tmp.Left;
                else perent.Right = tmp.Left;
            }
            else
            {
                if (tmp.Data.CompareTo(perent.Data) < 0) perent.Left = tmp.Right;
                else perent.Right = tmp.Right;
            }
        }
        private void RemoveMid(Node pernt,Node tmp)
        {
            Node tmp2 = tmp;
            pernt = tmp;
            tmp = tmp.Right;
            while (tmp.Left!=null)
            {
                pernt = tmp;
                tmp = tmp.Left;
            }
            if(tmp.Right!=null) //if must left has a right pointer
            {
                tmp2.Data = tmp.Data;
                RemoveMid(pernt, tmp);
            }
            else 
            {
                tmp2.Data = tmp.Data;
                RemoveEnd(pernt, tmp);
            }
        }
    }
    

}
